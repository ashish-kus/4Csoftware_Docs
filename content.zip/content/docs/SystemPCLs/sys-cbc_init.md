---
date: "2026-02-19T14:07:01+05:30"
draft: false
type: docs
weight: 17
title: "sys.cbc_init"
---

## sys.cbc_init()

### Purpose

sys.cbc_init() clears the 4C clipboard and initializes it with default data.

---

### Usage

```c
sys.cbc_init();
```

---

### Arguments

None

---

### Returns

None

---

### Where Used

sys.cbc_init() can be called anytime to initialize the 4C clipboard.

---

### Example

None

---

### Description

sys.cbc_init() clears the 4C clipboard and initializes it with default data. After calling `sys.cbc_init()`, the application is able to make a series of `sys.cbc_open()`, `sys.cbc_senddata()`, and `sys.cbc_close()` calls.

---

### Bugs / Features / Comments

None

---

### See Also

- sys.cbc_end()
- sys.cbc_open()
