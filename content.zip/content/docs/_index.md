---
title: Documentation
weight: 2
---

This is a demo of the theme's documentation layout.

## Hello, World

```go {filename="main.go"}
package main

import "fmt"

func main() {
    fmt.Println("Hello, World!")
}
```
